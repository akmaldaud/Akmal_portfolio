from django.shortcuts import render
from rest_framework.decorators import api_view
from .serializers import ItemSerializer
from rest_framework.response import Response
from rest_framework import status
from .models import Item

# Create your views here.
@api_view(['GET'])
def fetch_items(request):
    try:
        items = Item.objects.all()
        serializer = ItemSerializer(items, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    except Item.DoesNotExist:
        return Response("Item does not exist", status=status.HTTP_404_NOT_FOUND)

@api_view(['POST'])
def post_items(request):
    serializer = ItemSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['PATCH'])
def patch_items(request, item_id):
    try:
        item = Item.objects.get(pk=item_id)
    except Item.DoesNotExist:
        return Response({'error': 'Item not found'}, status=status.HTTP_404_NOT_FOUND)
    serializer = ItemSerializer(item, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    else:
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['DELETE'])
def delete_items(request, item_id):
    try:
        item = Item.objects.get(pk=item_id)
        item.delete()
        return Response({
            'message': 'Item deleted successfully',
            }, status=status.HTTP_204_NO_CONTENT)
    except Item.DoesNotExist:
        return Response({
            "error": "Item not found"
        }, status=status.HTTP_404_NOT_FOUND)
